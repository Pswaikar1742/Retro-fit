print 'Hello from Python 2'
import urllib2
def greet(name):
    print 'Hello, ' + name
